import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by davidgudeman on 7/10/15.
 */
public class myNodeList<T>
{
    List<Node> storage = new ArrayList<>();
    Node node = null;


    NodeList nodeList = new NodeList()
    {
        @Override
        public Node item(int index)
        {
            return null;
        }

        @Override
        public int getLength()
        {
            return 0;
        }
    };

    public myNodeList(NodeList nodeList)
    {
        this.nodeList = nodeList;
    }

    public myNodeList(){}



}
